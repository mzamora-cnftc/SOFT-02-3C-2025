/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.cenfotec;

import java.io.*;

/**
 * Clase EntradaConsolaSimple Esta clase contiene m�todos utilizarios para la
 * lectura de datos b�sicos y la selecci�n de un valor en un listado de
 * opciones. Entre las opciones de validaci�n de las entradas para facilitar la
 * escritura de c�digos sencillos que utilizan "consola". Algunas de las
 * funciones comentarias presentes est� la opci�n de cambiar el color de las
 * fuentes en la consola.
 *
 * Los listados de colores para la terminal fueron obtenidos del siguiente sitio
 * https://stackoverflow.com/questions/5762491/how-to-print-color-in-console-using-system-out-println
 *
 * @author Mauricio Andr�s Zamora Hern�ndez
 * @version 1.1
 */
public class EntradaConsolaSimple {

    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;

    /**
     * Este m�todo genera un "men�" con las opciones en un arreglo de String. El
     * m�todo coloca autom�ticamene el n�mero de selecci�n iniciando en 1.
     * Adem�s, este m�todo tiene validaciones para que solo se pueda seleccionar
     * valores v�lidos y controla excepciones por tipo de entrada incorrecto.
     *
     * @param etiqueta Texto que se coloca antes de la impresi�n del men�. Se
     * recomienda un texto que indique que significa las opciones.
     * @param opciones Las opciones a mostrar.
     * @return El n�mero seleccionado por el usuario del men� mostrado.
     */
    public static int seleccionarElementoTexto(String etiqueta, String[] opciones) {
        int resultado = 0;
        out.println(etiqueta);

        for (int i = 0; i < opciones.length; i++) {
            out.printf("%3d - %s\n", (i + 1), opciones[i]);
        }

        resultado = leerRangosEnteros("Seleccione el ID de la opci�n", 1, opciones.length);

        return resultado;
    }

    public static int seleccionarElementoEntero(String etiqueta, int[] opciones) {
        int resultado = 0;
        out.println(etiqueta);

        for (int i = 0; i < opciones.length; i++) {
            out.printf("%3d - %d\n", (i + 1), opciones[i]);
        }

        resultado = leerRangosEnteros("Seleccione el ID de la opci�n", 1, opciones.length);

        return resultado;
    }

    /**
     * Este m�todo permite la lectura de un n�mero entero. Si el usuario digita
     * algo que genere un error, el sistema contniuar� solicitando el valor
     * correcto.
     *
     * @param texto Es el texto utilizado como etiqueta para que el usuario sepa
     * que se le solicita. Si no desea imprimir una etiqueta, coloque "".
     * @return N�mero entero digitado por el usuario.
     */
    public static int leerEntero(String texto) {
        int resultado = 0;
        out.print(texto);

        boolean ocurrioUnaBronca = false;

        do {
            try {
                resultado = Integer.parseInt(in.readLine());
                ocurrioUnaBronca = false;
            } catch (Exception e) {
                ocurrioUnaBronca = true;
                out.println("Intente de nuevo, porque no digito un n�mero");
            }
        } while (ocurrioUnaBronca);

        return resultado;
    }

    /**
     * Este m�todo permite la lectura de un String (texto).
     *
     * @param texto Es el texto utilizado como etiqueta para que el usuario sepa
     * que se le solicita. Si no desea imprimir una etiqueta, coloque "".
     * @return String (texto) digitado por el usuario.
     */
    public static String leerString(String texto) {
        String resultado = null;
        out.print(texto);

        try {
            resultado = in.readLine();

        } catch (Exception e) {
        }

        return resultado;
    }

    /**
     * Este m�todo permite la lectura de un caracter (texto). Si el usuario
     * digite m�s de un caracter, toma el primero. NO PUEDE LEER ESPACIOS EN
     * BLANCO, DADO QUE LIMPIA TODOS LOS ESPACIOS.
     *
     * @param texto Es el texto utilizado como etiqueta para que el usuario sepa
     * que se le solicita. Si no desea imprimir una etiqueta, coloque "".
     * @return char (caracter) digitado por el usuario.
     */
    public static char leerCaracter(String texto) {
        String resultado = null;
        out.print(texto);

        try {
            resultado = in.readLine();

        } catch (Exception e) {
        }

        char salida = resultado.trim().charAt(0);

        return salida;
    }

    /**
     * Este m�todo leer un boolean (true/false), para esto se hace una pregunta
     * de tipo Si y NO, si el usuario escribe un Si, el sistema devuelve un
     * true, el usuario escoge No el sistema devuelve un false. Si no responde a
     * las opciones, el sistema sigue preguntando.
     *
     * @param pregunta Es el texto de la pregunta, no es necesario colocar los
     * signos de puntuaci�n.
     * @return boolean que corresopnde a la respuesta del usuario True para Si,
     * False para No
     */
    public static boolean leerBoolean(String pregunta) {
        char resultado = Character.UNASSIGNED;
        boolean ocurrioUnaBronca = false;

        out.printf("�%s? \n\tDigite S para Si, N para No, luego presione ENTER\n", pregunta);

        do {
            try {
                resultado = in.readLine().trim().toUpperCase().charAt(0);
                ocurrioUnaBronca = false;
                if (!(resultado == 'S' || resultado == 'N')) {
                    throw new Exception();
                }
            } catch (Exception e) {
                ocurrioUnaBronca = true;
                out.println("Intente de nuevo, Digite S para Si, N para No, luego presione ENTER");
            }
        } while (ocurrioUnaBronca);

        return resultado == 'S';
    }

    /**
     * Este m�todo permite la lectura de un n�mero doble. Si el usuario digita
     * algo que genere un error, el sistema contniuar� solicitando el valor
     * correcto.
     *
     * @param texto Es el texto utilizado como etiqueta para que el usuario sepa
     * que se le solicita. Si no desea imprimir una etiqueta, coloque "".
     * @return N�mero doble digitado por el usuario.
     */
    public static double leerDoble(String texto) {
        double resultado = 0;
        out.print(texto);

        boolean ocurrioUnaBronca = false;

        do {
            try {
                resultado = Double.parseDouble(in.readLine());
                ocurrioUnaBronca = false;
            } catch (Exception e) {
                ocurrioUnaBronca = true;
                out.println("Intente de nuevo, porque no digito un n�mero");
            }
        } while (ocurrioUnaBronca);

        return resultado;
    }

    /**
     * Este m�todo valida la lectura de un rango de valores enteros, ambos
     * l�mites inclusive. Si el usuario digita un valor fuera del rango, el
     * sistema le solitar� otro valor hasta encontrar un valor v�lido.
     *
     * @param etiqueta Es el texto utilizado como etiqueta para que el usuario
     * sepa que se le solicita.
     * @param min Valor m�nimo del rango
     * @param max Valor m�ximo del rango
     * @return N�mero entero digitado por el usuario.
     */
    public static int leerRangosEnteros(String etiqueta, int min, int max) {
        int resultado = 0;
        out.println(etiqueta);

        do {
            resultado = leerEntero("");
            if (resultado < min || resultado > max) {
                out.println("Valor fuera del rango [" + min + " al " + max + "], digite de nuevo");
            }

        } while (resultado < min || resultado > max);

        return resultado;
    }

    /**
     * Este m�todo valida la lectura de un rango de valores dobles, ambos
     * l�mites inclusive. Si el usuario digita un valor fuera del rango, el
     * sistema le solitar� otro valor hasta encontrar un valor v�lido.
     *
     * @param etiqueta Es el texto utilizado como etiqueta para que el usuario
     * sepa que se le solicita.
     * @param min Valor m�nimo del rango
     * @param max Valor m�ximo del rango
     * @return N�mero doble digitado por el usuario.
     */
    public static double leerRangosDobles(String etiqueta, double min, double max) {
        double resultado = 0;
        out.println(etiqueta);

        do {
            resultado = leerEntero("");
            if (resultado < min || resultado > max) {
                out.println("Valor fuera del rango [" + min + " al " + max + "], digite de nuevo");
            }

        } while (resultado < min || resultado > max);

        return resultado;
    }

    /**
     * Limpia la consola (en algunas terminales solo generar un bloque sin
     * contenido antes)
     */
    public static void limpiarConsola() {
        System.out.print("\033[2J");
    }

    /**
     * Genera un numero entre un rango de valores, ambos l�mites inclusive.
     *
     * @param inferior Valor inferior del l�mite
     * @param superior Valor superior del l�mite
     * @return N�mero entero generado aleatoriamente
     */
    public static int generarNumerosEntre(int inferior, int superior) {
        int rango = Math.max(inferior, superior) - Math.min(inferior, superior);
        return Math.min(inferior, superior) + generarNumeroAleatorio(rango);
    }

    /**
     * Genera un n�mero aleatorio entre 0 - n (ambos l�mites inclusive)
     *
     * @param n Valor l�mite m�ximo
     * @return N�mero entero generado aleatorimente
     */
    public static int generarNumeroAleatorio(int n) {
        // 0 - n (ambos inclusive)
        return (int) Math.round(Math.random() * n);
    }

    public static void establecerColorRojo() {
        System.out.print("\033[31m");
    }

    public static void establecerColorVerde() {
        System.out.print("\033[32m");
    }

    public static void establecerColorAmarillo() {
        System.out.print("\033[33m");
    }

    public static void establecerColorAzul() {
        System.out.print("\033[34m");
    }

    public static void establecerColorMangenta() {
        System.out.print("\033[35m");
    }

    public static void establecerColorCian() {
        System.out.print("\033[36m");
    }

    public static void establecerColorBlanco() {
        System.out.print("\033[37m");
    }

    public static void pausar() {
        System.out.println("Presione <Enter> para continuar...");
        try {
            System.in.read();
        } catch (Exception e) {

        }
    }

    public static void reiniciarColores() {
        System.out.print("\033[0m");
    }

    public static void establecerFondoColorBlanco() {
        System.out.print("\033[47m");
    }

    public static void establecerFondoColorRojo() {
        System.out.print("\033[41m");
    }

    public static void establecerFondoColorVerde() {
        System.out.print("\033[42m");
    }

    public static void establecerFondoColorAmarillo() {
        System.out.print("\033[43m");
    }

    public static void establecerFondoColorAzul() {
        System.out.print("\033[44m");
    }

    public static void establecerFondoColorMangenta() {
        System.out.print("\033[45m");
    }

    public static void establecerFondoColorCian() {
        System.out.print("\033[46m");
    }

    public static void establecerFondoColorNegro() {
        System.out.print("\033[40m");
    }

    /**
     * Esta funci�n permite escribir archivos de texto
     *
     * @param nombreArchivo nombre del archivo, se recomienda poner .txt al
     * final para que se guarde con la extensi�n de texto. Si no pone extensi�n,
     * el archivo se guarda sin esta y el sistema operativo no sabe con que
     * asociarlo para abrirlo.
     * @param contenido Es la variable que contiene el texto a escribir el
     * archivo.
     */
    public static void escribirArchivo(String nombreArchivo, String contenido) {
        try (PrintWriter escritor = new PrintWriter(nombreArchivo)) {
            escritor.print(contenido);
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }

}
