/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package miprimerproyecto;

import java.util.Scanner;

/**
 *
 * @author mauri
 */
public class Principal {

    private static int x = 100;
    private static int y = 1500;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int z = 500;
        int x = 7;  // esta X esconde a la X de atributo
        Scanner scanner = new Scanner(System.in);
        System.out.println("Hola, Mundo!");
        System.out.println("Soy Mauricio");
        System.out.println("Digite el valor de x: ");
        x = scanner.nextInt();
        System.out.println("X es: " + x);
        System.out.println("Digite el valor de z: ");
        z = scanner.nextInt();
        System.out.println("Z es: " + z);
        System.out.println(y);
        y = 150;
        System.out.println(y);

        if (x >= z) {
            //si es true
            System.out.println("Ganó X!");
        } else {
            //si es false
            System.out.println("Ganó Z!");
        }

        scanner.close();
    }

}


/*
Comentario tipo C
 */
