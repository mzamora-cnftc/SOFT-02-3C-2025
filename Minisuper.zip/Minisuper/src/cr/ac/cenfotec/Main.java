/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cr.ac.cenfotec;

import javax.swing.JOptionPane;

/**
 *
 * @author Mauricio Andr�s Zamora Hern�ndez
 *
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Object[] opciones = {"Cargar datos de prueba", "Agregar Producto", "Ver Inventario", "Editar Inventario", "Calcular Costo Total Inventario", "Salir"};
        String opcionesSeleccionada = null;
        Inventario inventario = new Inventario(100);
        boolean impar = true;
        Producto[] lista = null;
        int id;
        Producto prod = null;
        boolean pregunta = false;
        String sku, nombre;
        double cantidad, costo, precio;

        do {
            opcionesSeleccionada = EntradaVisualSimple.preguntarPorOpciones(opciones, "Seleccione una opci�n del men�", "Men� Principal");
            switch (opcionesSeleccionada) {
                case "Agregar Producto":
                    System.out.println("Usted esta agregando inventario");

                    prod = null;
                    EntradaConsolaSimple.limpiarConsola();
                    System.out.println("REGISTRO DE PRODUCTOS");
                    sku = EntradaConsolaSimple.leerString("Digite el SKU: ");
                    nombre = EntradaConsolaSimple.leerString("Digite el NOMBRE: ");
                    costo = EntradaConsolaSimple.leerDoble("Digite el COSTO: ");
                    precio = EntradaConsolaSimple.leerDoble("Digite el PRECIO: ");
                    cantidad = EntradaConsolaSimple.leerDoble("Digite la CANTIDAD: ");
                    prod = new Producto(sku, nombre, cantidad, costo, precio);
                    inventario.agregar(prod);
                    EntradaConsolaSimple.pausar();
                    EntradaConsolaSimple.limpiarConsola();
                    break;
                case "Ver Inventario":

                    System.out.println("Usted esta viendo el inventario");
                    EntradaConsolaSimple.limpiarConsola();
                    System.out.println(Producto.enStringTitulo());
                    lista = inventario.getProductos();
                    for (Producto producto : lista) {
                        if (producto != null) {
                            if (impar) {
                                EntradaConsolaSimple.establecerColorAzul();
                            } else {
                                EntradaConsolaSimple.establecerColorVerde();
                            }
                            System.out.println(producto.enString());
                            impar = !impar;
                        }
                    }

                    EntradaConsolaSimple.pausar();
                    EntradaConsolaSimple.limpiarConsola();
                    EntradaConsolaSimple.reiniciarColores();
                    break;
                case "Calcular Costo Total Inventario":
                    System.out.println("Usted esta calculando el inventario");
                    JOptionPane.showMessageDialog(null, String.format("El costo total es %.2f", inventario.calcularCostoTotal()), "Costo Total", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case "Salir":
                    System.out.println("Hasta la vista, baby");
                    break;
                case "Editar Inventario":
                    System.out.println("Usted esta editando el inventario");
                    EntradaConsolaSimple.limpiarConsola();
                    System.out.println(String.format("%2s %-40s", "ID", "NOMBRE DEL PRODUCTO"));
                    lista = inventario.getProductos();
                    for (int i = 0; i < lista.length; i++) {
                        Producto producto = lista[i];
                        if (impar) {
                            EntradaConsolaSimple.establecerColorAzul();
                        } else {
                            EntradaConsolaSimple.establecerColorVerde();
                        }

                        if (producto != null) {
                            System.out.println(String.format("%2d %-40s", i, producto.getNombre()));
                            impar = !impar;
                        }
                    }
                    EntradaConsolaSimple.establecerColorRojo();
                    System.out.println("SELECCIONE EL ID A EDITAR");
                    EntradaConsolaSimple.reiniciarColores();
                    id = EntradaConsolaSimple.leerEntero("Digite el ID: ");

                    prod = lista[id];

                    if (prod != null) {
                        // si hay producto
                        System.out.println("NOMBRE: " + prod.getNombre());
                        pregunta = EntradaConsolaSimple.leerBoolean("Desea cambiar el nombre");
                        if (pregunta) {
                            nombre = EntradaConsolaSimple.leerString("Digite el nuevo nombre: ");
                            prod.setNombre(nombre);
                        }
                        
                        System.out.println("CANTIDAD: " + prod.getCantidad());
                        pregunta = EntradaConsolaSimple.leerBoolean("Desea cambiar la cantidad");
                        if (pregunta) {
                            cantidad = EntradaConsolaSimple.leerDoble("Digite la nueva cantidad: ");
                            prod.setCantidad(cantidad);
                        }
                    } else {
                        // en caso que este null
                        System.out.println("ERROR");
                    }

                    EntradaConsolaSimple.pausar();
                    EntradaConsolaSimple.limpiarConsola();
                    EntradaConsolaSimple.reiniciarColores();

                    break;
                case "Cargar datos de prueba":
                    System.out.println("Cargando datos ...");
                    Producto temp;
                    temp = new Producto("74410025612", "Heladito Cipres", 10, 500, 1200);
                    inventario.agregar(temp);
                    temp = new Producto("74410051212", "Lechita Cipres", 15, 1000, 1100);
                    inventario.agregar(temp);
                    temp = new Producto("74410012812", "Chocalito Cipres", 1, 1500, 3500);
                    inventario.agregar(temp);
                    temp = new Producto("74410006412", "Arroz Sinsabor", 20, 250, 200);
                    inventario.agregar(temp);
                    temp = new Producto("74410003212", "Frijoles", 50, 200, 300);
                    inventario.agregar(temp);
                    temp = new Producto("74410001612", "Salsa tipo inglesa", 10, 500, 1200);
                    inventario.agregar(temp);
                    temp = new Producto("74410000812", "Sal sinsalida", 100, 50, 120);
                    inventario.agregar(temp);
                    temp = new Producto("74410000412", "Azucar amargadita", 100, 500, 1000);
                    inventario.agregar(temp);
                    temp = new Producto("74410000212", "Heladito Cipres", 10, 500, 1200);
                    inventario.agregar(temp);
                    temp = new Producto("74410000112", "Aceite dorado", 50, 750, 1250);
                    inventario.agregar(temp);

                    break;

            }

        } while (!"Salir".equalsIgnoreCase(opcionesSeleccionada));

    }

}
