/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.cenfotec;

/**
 *
 * @author mauri
 */
public class Probador {
    public static void main(String[] args) {
        Producto p1 = new Producto("744123456", "Queque de navidad", 10, 1000, 2500);
        Producto p2 = new Producto("744654123", "Rompope de navidad", 5, 700, 1500);
        
        Factura f = new Factura("Mauricio Zamora");
        f.agregarLinea(p1, 5);
        f.agregarLinea(p2, 2);
        
        Factura f2 = new Factura("Hazel Daniela");
        f2.agregarLinea(p2, 1);
        
        System.out.println(f.enString());
       System.out.println(f2.enString());
    }
}
