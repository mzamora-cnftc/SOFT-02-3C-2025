/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.cenfotec;

/**
 *
 * @author Mauricio
 */
public class Inventario {
    private Producto[] productos = null;

    public Inventario(int n) {
        setProductos(new Producto[n]);
    }
    
    public double calcularCostoTotal() {
        double total = 0;
        for (Producto producto : productos) {
            if (producto != null) {
                total = total + producto.getCantidad() * producto.getCosto();
            }
        }
        
        return total;
    }
    
    public boolean agregar(Producto prod) {
        boolean resultado = false;
        for (int i = 0; i < productos.length; i++) {
            if (productos[i] == null) {
                productos[i] = prod;
                resultado = true;
                break;
            }
        }
        
        return resultado;
    }
    

    /**
     * @return the productos
     */
    public Producto[] getProductos() {
        return productos;
    }

    /**
     * @param productos the productos to set
     */
    public void setProductos(Producto[] productos) {
        this.productos = productos;
    }
    
}
