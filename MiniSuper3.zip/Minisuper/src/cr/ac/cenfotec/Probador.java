/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.cenfotec;

import java.util.ArrayList;

/**
 *
 * @author mauri
 */
public class Probador {
    public static void main(String[] args) {
        Producto p1 = new Producto("744123456", "Queque de navidad", 10, 1000, 2500);
        Producto p2 = new Producto("744654123", "Rompope de navidad", 5, 700, 1500);
        Producto p3 = new Producto("744121344", "Tamal especial de cerdo", 5, 3700, 6500);
        Producto p4 = new Producto("744854714", "Pierna de cerdo", 5, 1200, 7500);
        
        ArrayList<Producto> listaProductos = null;
        listaProductos = new ArrayList<Producto>();
        
        listaProductos.add(p1);
        listaProductos.add(p2);
        listaProductos.add(p3);
        listaProductos.add(p4);
        
        Producto primerProd = listaProductos.get(0);
        System.out.println("Primero: "+primerProd.getNombre());
        int n = listaProductos.size();
        System.out.println("La lista tiene " + n + " elementos");
        Producto ultimoProd = listaProductos.get(n-1);
        System.out.println("�ltimo: "+ultimoProd.getNombre());
        
        System.out.println("Opci�n 1 para recorrer todos");
        for (int i = 0; i < listaProductos.size(); i++) {
            System.out.println("Producto " + (i+1) +": " + listaProductos.get(i).getNombre());
            
        }
        Producto prodQuitado = listaProductos.remove(2);
        System.out.println("Quitado: " + prodQuitado.getNombre());
        
        System.out.println("Opci�n 2 para recorrer todos");
        for (Producto producto : listaProductos) {
            System.out.println(producto.getNombre());
        }
        
        Factura f = new Factura("Mauricio Zamora");
        f.agregarLinea(p1, 5);
        f.agregarLinea(p2, 2);
        
        Factura f2 = new Factura("Hazel Daniela");
        f2.agregarLinea(p2, 1);
        
        System.out.println(f.enString());
       System.out.println(f2.enString());
    }
}
