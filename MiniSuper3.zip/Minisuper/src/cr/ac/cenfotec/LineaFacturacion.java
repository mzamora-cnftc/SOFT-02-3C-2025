/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.cenfotec;

/**
 *
 * @author Mauricio
 */
public class LineaFacturacion {
    private double cantidad = 0;
    private double costo = 0;
    private double precio = 0;
    private Producto producto = null;

    public LineaFacturacion(double cantidad, Producto prod) {
        this.producto = prod;
        this.cantidad = cantidad;
        this.costo = this.producto.getCosto();
        this.precio = this.producto.getPrecio();
    }
    
    public static String enStringTitulo() {
        return String.format("%-10s %-50s %-10s %-10s %-10s",
                "CODIGO", "NOMBRE DEL PRODUCTO", "CANTIDAD", "PRECIO. U.", "TOTAL");        
    }
    
    public String enString() {
        return String.format("%10s %-50s %9.2f %9.2f %9.2f",
                getProducto().getSku(), getProducto().getNombre(), getCantidad(), getPrecio(), calcularMontoTotalLinea());
    }
    
    public double calcularMontoTotalLinea() {
        return getCantidad() * getPrecio();
    }
    
    public double calcularCostoTotalLinea() {
        return getCantidad() * getCosto();
    }
    
    public double calcularUtilidadPorLinea() {
        return calcularMontoTotalLinea() - calcularCostoTotalLinea();
    }

    /**
     * @return the producto
     */
    public Producto getProducto() {
        return producto;
    }

    /**
     * @param producto the producto to set
     */
    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    /**
     * @return the cantidad
     */
    public double getCantidad() {
        return cantidad;
    }

    /**
     * @param cantidad the cantidad to set
     */
    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * @return the costo
     */
    public double getCosto() {
        return costo;
    }

    /**
     * @param costo the costo to set
     */
    public void setCosto(double costo) {
        this.costo = costo;
    }

    /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
}
