/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.cenfotec;

/**
 *
 * @author Mauricio
 */
public class Producto {
    private String sku;
    private String nombre;
    private double cantidad;
    private double costo;
    private double precio;

    public Producto(String sku, String nombre, double cantidad, double costo, double precio) {
        this.sku = sku;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.costo = costo;
        this.precio = precio;
    }

    public static String enStringTitulo() {
        return String.format("%-10s %-50s %-10s %-10s %-10s",
                "CODIGO", "NOMBRE DEL PRODUCTO", "CANTIDAD", "COSTO", "TOTAL");        
    }
    
    public String enString() {
        return String.format("%10s %-50s %9.2f %9.2f %9.2f",
                getSku(), getNombre(), getCantidad(), getCosto(), getPrecio());
    }
    
    /**
     * @return the sku
     */
    public String getSku() {
        return sku.toUpperCase();
    }

    /**
     * @param sku the sku to set
     */
    public void setSku(String sku) {
        if (sku != null) {
            this.sku = sku;
        }
        
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre.toUpperCase();
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        if(nombre != null) {
            this.nombre = nombre;
        }
        
    }

    /**
     * @return the cantidad
     */
    public double getCantidad() {
        return cantidad;
    }

    /**
     * @param cantidad the cantidad to set
     */
    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * @return the costo
     */
    public double getCosto() {
        return costo;
    }

    /**
     * @param costo the costo to set
     */
    public void setCosto(double costo) {
        if (costo >= 0) {
            this.costo = costo;
        }
        
    }

    /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        if (precio >= 0) {
            this.precio = precio;
        }
        
    }
}
