/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.cenfotec;

/**
 *
 * @author Mauricio
 */
public class Factura {
    private static int siguiente = 1;
    private int numero;
    private String cliente;
    private LineaFacturacion[] lineas = null;

    public Factura(String cliente) {
        this.cliente = cliente;
        this.numero = siguiente++;
        lineas = new LineaFacturacion[5];
    }
    
        public String enString() {
            StringBuilder sb = new StringBuilder();
            sb.append("DETALLE DE FACTURA\n");
            sb.append("NUMERO: "+ getNumero() + "\n");
            sb.append("CLIENTE: "+ getCliente()+ "\n");
            sb.append(LineaFacturacion.enStringTitulo()+ "\n");
            for (LineaFacturacion linea : lineas) {
                if (linea != null) {
                    sb.append(linea.enString()+ "\n");
                }
            }
            
            sb.append("TOTAL: "+calcularMontoTotal());

        return sb.toString();
    }
        
    public boolean agregarLinea(Producto p, double cantidad) {
        LineaFacturacion lf = new LineaFacturacion(cantidad, p);
        return agregarLinea(lf);
    }

    public boolean agregarLinea(LineaFacturacion linea) {
        boolean resultado = false;
        for (int i = 0; i < lineas.length; i++) {
            LineaFacturacion l = lineas[i];
            if (l == null) {
                lineas[i] = linea;
                resultado = true;
                break;
            }
            
        }
        return resultado;
    }
    
    public double calcularMontoTotal() {
        double total = 0;
        for (LineaFacturacion linea : lineas) {
            if (linea != null) {
                total = total + linea.calcularMontoTotalLinea();
            }
        }
        
        return total;
    }
    
    /**
     * @return the siguiente
     */
    public static int getSiguiente() {
        return siguiente;
    }

    /**
     * @param aSiguiente the siguiente to set
     */
    public static void setSiguiente(int aSiguiente) {
        siguiente = aSiguiente;
    }

    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * @return the cliente
     */
    public String getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
    
    
}
