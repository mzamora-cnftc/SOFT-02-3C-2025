/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucenfotec;

import javax.swing.Icon;
import javax.swing.JOptionPane;

/**
 * Clase utilitaria para manejar entradas de datos mediante cuadros de di�logo.
 * Proporciona m�todos para solicitar n�meros, booleanos y opciones al usuario
 * con validaci�n de entrada.
 * 
 * @author Mauricio Andr�s Zamora Hern�ndez
 * @version 1.0
 */
public class Entradas {
    
    /**
     * Solicita al usuario un n�mero decimal mediante un cuadro de di�logo.
     * 
     * @param pregunta El mensaje que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @return El n�mero double ingresado por el usuario, o null si la entrada no es v�lida
     */
    public static Double preguntarPorNumeroDoble(String pregunta, String titulo) {
        String respuesta = JOptionPane.showInputDialog(null,
                pregunta,
                titulo,
                JOptionPane.QUESTION_MESSAGE);
        Double salida = null;
        try {
            salida = Double.parseDouble(respuesta);
        } catch (Exception e) {
            // No se hace nada, se retorna null
        }
        return salida;
    }
    
    /**
     * Solicita al usuario un n�mero entero mediante un cuadro de di�logo.
     * 
     * @param pregunta El mensaje que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @return El n�mero entero ingresado por el usuario, o null si la entrada no es v�lida
     */
    public static Integer preguntarPorNumeroEntero(String pregunta, String titulo) {
        String respuesta = JOptionPane.showInputDialog(null,
                pregunta,
                titulo,
                JOptionPane.QUESTION_MESSAGE);
        Integer salida = null;
        try {
            salida = Integer.parseInt(respuesta);
        } catch (Exception e) {
            // No se hace nada, se retorna null
        }
        return salida;
    }

    /**
     * Solicita al usuario una confirmaci�n S�/No mediante un cuadro de di�logo.
     * 
     * @param pregunta El mensaje de confirmaci�n que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @return true si el usuario selecciona "S�", false si selecciona "No" o cierra la ventana
     */
    public static boolean preguntarSioNo(String pregunta, String titulo) {
        boolean salida = false;
        // 1. Define las etiquetas de los botones en espa�ol
        Object[] opcionesPersonalizadas = {"S�", "No"};

        // Puedes usar null si no quieres un icono o una de las constantes de JOptionPane
        Icon icono = null;

        // 2. Llama a showOptionDialog para usar las etiquetas
        int respuesta = JOptionPane.showOptionDialog(
                null, // Componente padre (null para centrar)
                pregunta, // Mensaje
                titulo, // T�tulo de la ventana
                JOptionPane.YES_NO_OPTION, // Tipo de botones (define el comportamiento)
                JOptionPane.QUESTION_MESSAGE, // Tipo de mensaje/icono (Pregunta)
                icono, // Icono a mostrar
                opcionesPersonalizadas, // *** ARRAY DE ETIQUETAS PERSONALIZADAS ***
                opcionesPersonalizadas[0] // Opci�n por defecto (Aqu� es "S�")
        );

        // 3. Manejar el resultado
        // Aunque los textos son personalizados, el valor retornado sigue siendo un entero:
        // 0 -> Opci�n 1 ("S�")
        // 1 -> Opci�n 2 ("No")
        // -1 -> Cerrar Ventana (X)
        salida = respuesta == 0;
        return salida;
    }
    
    /**
     * Solicita al usuario que seleccione una opci�n de una lista mediante un cuadro de di�logo.
     * 
     * @param opciones Array de objetos que representan las opciones disponibles
     * @param mensaje El mensaje que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @return La opci�n seleccionada como String, o null si no se selecciona ninguna opci�n
     */
    public static String preguntarPorOpciones(Object[] opciones, String mensaje, String titulo) {
        String salida = null;
        // 1. Define las opciones disponibles como un array de Strings
        //Object[] opciones = {"Manzana", "Pera", "Naranja", "Uva"};

        // 2. Muestra el di�logo de opci�n
        int seleccion = JOptionPane.showOptionDialog(
                null, // Componente padre
                mensaje, // Mensaje
                titulo, // T�tulo
                JOptionPane.DEFAULT_OPTION, // Tipo de opci�n (no es necesario un icono por defecto)
                JOptionPane.QUESTION_MESSAGE, // Tipo de mensaje/icono (un signo de pregunta)
                null, // Icono personalizado (null = usa el predeterminado)
                opciones, // Array de botones a mostrar
                opciones[0] // Opci�n seleccionada por defecto
        );
        if (seleccion >= 0 && seleccion < opciones.length) {
            salida = (String) opciones[seleccion];
        }
        return salida;
    }
    
    /**
     * Solicita repetidamente un n�mero decimal al usuario hasta que ingrese un valor v�lido.
     * 
     * @param pregunta El mensaje que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @param mensajeError El mensaje de error que se muestra cuando la entrada no es v�lida
     * @return El n�mero double v�lido ingresado por el usuario
     */
    public static double leerNumeroDobleHastaValido(String pregunta, String titulo, String mensajeError) {
        Double numero;
        do {
            numero = preguntarPorNumeroDoble(pregunta, titulo);
            if (numero == null) {
                JOptionPane.showMessageDialog(null, mensajeError, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (numero == null);
        return numero;
    }
    
    /**
     * Solicita repetidamente un n�mero decimal al usuario hasta que ingrese un valor v�lido.
     * Usa un mensaje de error por defecto.
     * 
     * @param pregunta El mensaje que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @return El n�mero double v�lido ingresado por el usuario
     */
    public static double leerNumeroDobleHastaValido(String pregunta, String titulo) {
        return leerNumeroDobleHastaValido(pregunta, titulo, "Por favor, ingrese un n�mero decimal v�lido.");
    }
    
    /**
     * Solicita repetidamente un n�mero entero al usuario hasta que ingrese un valor v�lido.
     * 
     * @param pregunta El mensaje que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @param mensajeError El mensaje de error que se muestra cuando la entrada no es v�lida
     * @return El n�mero entero v�lido ingresado por el usuario
     */
    public static int leerNumeroEnteroHastaValido(String pregunta, String titulo, String mensajeError) {
        Integer numero;
        do {
            numero = preguntarPorNumeroEntero(pregunta, titulo);
            if (numero == null) {
                JOptionPane.showMessageDialog(null, mensajeError, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (numero == null);
        return numero;
    }
    
    /**
     * Solicita repetidamente un n�mero entero al usuario hasta que ingrese un valor v�lido.
     * Usa un mensaje de error por defecto.
     * 
     * @param pregunta El mensaje que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @return El n�mero entero v�lido ingresado por el usuario
     */
    public static int leerNumeroEnteroHastaValido(String pregunta, String titulo) {
        return leerNumeroEnteroHastaValido(pregunta, titulo, "Por favor, ingrese un n�mero entero v�lido.");
    }
    
    /**
     * Solicita repetidamente un valor booleano (S�/No) al usuario hasta que haga una selecci�n v�lida.
     * 
     * @param pregunta El mensaje de confirmaci�n que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @param mensajeError El mensaje de error que se muestra cuando no se hace una selecci�n
     * @return true si el usuario selecciona "S�", false si selecciona "No"
     */
    public static boolean leerBooleanoHastaValido(String pregunta, String titulo, String mensajeError) {
        int respuesta;
        do {
            Object[] opciones = {"S�", "No"};
            respuesta = JOptionPane.showOptionDialog(
                    null,
                    pregunta,
                    titulo,
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
            );
            if (respuesta == JOptionPane.CLOSED_OPTION) {
                JOptionPane.showMessageDialog(null, mensajeError, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (respuesta == JOptionPane.CLOSED_OPTION);
        
        return respuesta == 0;
    }
    
    /**
     * Solicita repetidamente un valor booleano (S�/No) al usuario hasta que haga una selecci�n v�lida.
     * Usa un mensaje de error por defecto.
     * 
     * @param pregunta El mensaje de confirmaci�n que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @return true si el usuario selecciona "S�", false si selecciona "No"
     */
    public static boolean leerBooleanoHastaValido(String pregunta, String titulo) {
        return leerBooleanoHastaValido(pregunta, titulo, "Por favor, seleccione S� o No.");
    }
    
    /**
     * Solicita repetidamente al usuario que seleccione una opci�n hasta que haga una selecci�n v�lida.
     * 
     * @param opciones Array de objetos que representan las opciones disponibles
     * @param mensaje El mensaje que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @param mensajeError El mensaje de error que se muestra cuando no se selecciona una opci�n
     * @return La opci�n seleccionada como String
     */
    public static String leerOpcionHastaValida(Object[] opciones, String mensaje, String titulo, String mensajeError) {
        String opcion;
        do {
            opcion = preguntarPorOpciones(opciones, mensaje, titulo);
            if (opcion == null) {
                JOptionPane.showMessageDialog(null, mensajeError, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (opcion == null);
        return opcion;
    }
    
    /**
     * Solicita repetidamente al usuario que seleccione una opci�n hasta que haga una selecci�n v�lida.
     * Usa un mensaje de error por defecto.
     * 
     * @param opciones Array de objetos que representan las opciones disponibles
     * @param mensaje El mensaje que se mostrar� al usuario
     * @param titulo El t�tulo del cuadro de di�logo
     * @return La opci�n seleccionada como String
     */
    public static String leerOpcionHastaValida(Object[] opciones, String mensaje, String titulo) {
        return leerOpcionHastaValida(opciones, mensaje, titulo, "Por favor, seleccione una opci�n v�lida.");
    }
    
    /**
     * Solicita repetidamente un n�mero entero al usuario dentro de un rango espec�fico hasta que ingrese un valor v�lido.
     * 
     * @param pregunta El mensaje que se mostrar� al usuario (se incluir� autom�ticamente el rango)
     * @param titulo El t�tulo del cuadro de di�logo
     * @param minimo El valor m�nimo permitido (inclusive)
     * @param maximo El valor m�ximo permitido (inclusive)
     * @param mensajeError El mensaje de error que se muestra cuando la entrada no es v�lida
     * @return El n�mero entero v�lido dentro del rango especificado
     */
    public static int leerNumeroEnteroEnRango(String pregunta, String titulo, int minimo, int maximo, String mensajeError) {
        Integer numero;
        String preguntaConRango = pregunta + " (" + minimo + " - " + maximo + "):";
        
        do {
            numero = preguntarPorNumeroEntero(preguntaConRango, titulo);
            if (numero == null || numero < minimo || numero > maximo) {
                JOptionPane.showMessageDialog(null, mensajeError, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (numero == null || numero < minimo || numero > maximo);
        return numero;
    }
    
    /**
     * Solicita repetidamente un n�mero entero al usuario dentro de un rango espec�fico hasta que ingrese un valor v�lido.
     * Usa un mensaje de error por defecto.
     * 
     * @param pregunta El mensaje que se mostrar� al usuario (se incluir� autom�ticamente el rango)
     * @param titulo El t�tulo del cuadro de di�logo
     * @param minimo El valor m�nimo permitido (inclusive)
     * @param maximo El valor m�ximo permitido (inclusive)
     * @return El n�mero entero v�lido dentro del rango especificado
     */
    public static int leerNumeroEnteroEnRango(String pregunta, String titulo, int minimo, int maximo) {
        return leerNumeroEnteroEnRango(pregunta, titulo, minimo, maximo, 
                "Por favor, ingrese un n�mero entero v�lido entre " + minimo + " y " + maximo + ".");
    }
    
    /**
     * Solicita repetidamente un n�mero decimal al usuario dentro de un rango espec�fico hasta que ingrese un valor v�lido.
     * 
     * @param pregunta El mensaje que se mostrar� al usuario (se incluir� autom�ticamente el rango)
     * @param titulo El t�tulo del cuadro de di�logo
     * @param minimo El valor m�nimo permitido (inclusive)
     * @param maximo El valor m�ximo permitido (inclusive)
     * @param mensajeError El mensaje de error que se muestra cuando la entrada no es v�lida
     * @return El n�mero decimal v�lido dentro del rango especificado
     */
    public static double leerNumeroDobleEnRango(String pregunta, String titulo, double minimo, double maximo, String mensajeError) {
        Double numero;
        String preguntaConRango = pregunta + " (" + minimo + " - " + maximo + "):";
        
        do {
            numero = preguntarPorNumeroDoble(preguntaConRango, titulo);
            if (numero == null || numero < minimo || numero > maximo) {
                JOptionPane.showMessageDialog(null, mensajeError, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (numero == null || numero < minimo || numero > maximo);
        return numero;
    }
    
    /**
     * Solicita repetidamente un n�mero decimal al usuario dentro de un rango espec�fico hasta que ingrese un valor v�lido.
     * Usa un mensaje de error por defecto.
     * 
     * @param pregunta El mensaje que se mostrar� al usuario (se incluir� autom�ticamente el rango)
     * @param titulo El t�tulo del cuadro de di�logo
     * @param minimo El valor m�nimo permitido (inclusive)
     * @param maximo El valor m�ximo permitido (inclusive)
     * @return El n�mero decimal v�lido dentro del rango especificado
     */
    public static double leerNumeroDobleEnRango(String pregunta, String titulo, double minimo, double maximo) {
        return leerNumeroDobleEnRango(pregunta, titulo, minimo, maximo, 
                "Por favor, ingrese un n�mero decimal v�lido entre " + minimo + " y " + maximo + ".");
    }
}