/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica;

import cr.ac.ucenfotec.Entradas;

/**
 *
 * @author Mauricio Andr�s Zamora Hern�ndez
 */
public class Ejercicio03 {

    public static void main(String[] args) {
        int opcionMenu, cantidadVentas = 0;
        double totalVentas = 0, descuentoVentas;
        String textoMenu = null;

        textoMenu = String.format("1 %-15s%n 2 %-15s%n 3 %-15s%n 4 %-15s%n 5 %-15s%n", "Caf� (1000)", "T� (800)", "Galleta (1200)", "S�ndwich (2500)", "Salir");
        do {
            opcionMenu = Entradas.leerNumeroEnteroEnRango(textoMenu, "MENU", 1, 5, "Digite opci�n v�lida del men�");
            cantidadVentas++;
            switch (opcionMenu) {
                case 1:
                    totalVentas += 1000;
                    break;
                case 2:
                    totalVentas += 800;
                    break;
                case 3:
                    totalVentas += 1200;
                    break;
                case 4:
                    totalVentas += 2500;
                    break;
                case 5:
                    cantidadVentas--;
                    break;
            }
        } while (opcionMenu != 5);
        System.out.println("RESULTADOS");
        System.out.printf("CANTIDAD DE PRODUCTOS : %d%n", cantidadVentas);
        if (cantidadVentas >= 3 && totalVentas >= 5_000) {
            descuentoVentas = totalVentas * 0.1;
            System.out.printf("DESCUENTO : %.2f%n", descuentoVentas);
            System.out.printf("TOTAL DE VENTAS : %.2f%n", totalVentas - descuentoVentas);
        } else {
            System.out.printf("TOTAL DE VENTAS : %.2f%n", totalVentas);
        }
    }
}
