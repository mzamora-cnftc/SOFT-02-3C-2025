/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica;

import cr.ac.ucenfotec.Entradas;

/**
 *
 * @author Mauricio Andr�s Zamora Hern�ndez
 */
public class Ejercicio02 {

    public static void main(String[] args) {
        int numeroPasos = 0, dias = 0, pasos = 0, diasCumplioMeta = 0;
        double promedioDiario = 0;

        while (dias < 7) {
            pasos = Entradas.preguntarPorNumeroEntero("Digite los pasos del d�a", "Pasos diarios");
            if (pasos >= 10_000) {
                diasCumplioMeta++;
            }
            numeroPasos += pasos;
            dias++;
        }
        promedioDiario = (double) numeroPasos / dias;

        System.out.print(String.format("%40s: %8d %n", "Pasos semanales", numeroPasos));
        System.out.print(String.format("%40s: %8.2f %n", "Promedio de pasos diario", promedioDiario));
        System.out.print(String.format("%40s: %8d %n", "D�as que cumpli� la meta", diasCumplioMeta));
        
        if (diasCumplioMeta == 7) {
            System.out.println("�Excelente disciplina!");
        } else if (diasCumplioMeta > 0) {
            System.out.println("Vas por buen camino");
        } else {
            System.out.println("Necesitas moverte m�s");
            
        }
    }
}
