/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica;

import cr.ac.ucenfotec.Entradas;


/**
 *
 * @author Mauricio Andr�s Zamora Hern�ndez
 */
public class Ejercicio01 {



    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Integer edad = null;
        boolean vieneAcompa�ado = false,
                esEstudianteConCarneValido = false,
                esPelicula18Mas = false,
                puedeIngresar = false;

        edad = Entradas.preguntarPorNumeroEntero("�Cu�l es su edad?", "Verificaci�n de edad");
        esPelicula18Mas = Entradas.preguntarSioNo("�Es una pel�cula +18?", "Verificaci�n de pel�cula");

        if (edad < 12) {
            vieneAcompa�ado = Entradas.preguntarSioNo("�Viene acompa�ado el menor?", "Verificaci�n de compa��a");
            puedeIngresar = vieneAcompa�ado && !esPelicula18Mas;
        } else if (edad < 18) {
            puedeIngresar = !esPelicula18Mas;
        } else {
            puedeIngresar = true;
        }
        
        if (puedeIngresar) {
            esEstudianteConCarneValido = Entradas.preguntarSioNo("�Es estudiante con carn� valido?", "Verificaci�n de estudiante");
            if (esEstudianteConCarneValido) {
                System.out.println("Se le har� un descuento del 20%");
            }
        } else {
            System.out.println("No puede ingresar");
        }
    }

}
