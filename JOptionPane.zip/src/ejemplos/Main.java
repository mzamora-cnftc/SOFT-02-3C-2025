/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplos;

import javax.swing.Icon;
import javax.swing.JOptionPane;

/**
 *
 * @author mauri
 */
public class Main {

    public static String preguntarPorOpciones(Object[] opciones, String mensaje, String titulo) {
        String salida = null;
        // 1. Define las opciones disponibles como un array de Strings
        //Object[] opciones = {"Manzana", "Pera", "Naranja", "Uva"};

        // 2. Muestra el di�logo de opci�n
        int seleccion = JOptionPane.showOptionDialog(
                null, // Componente padre
                mensaje, // Mensaje
                titulo, // T�tulo
                JOptionPane.DEFAULT_OPTION, // Tipo de opci�n (no es necesario un icono por defecto)
                JOptionPane.QUESTION_MESSAGE, // Tipo de mensaje/icono (un signo de pregunta)
                null, // Icono personalizado (null = usa el predeterminado)
                opciones, // Array de botones a mostrar
                opciones[0] // Opci�n seleccionada por defecto
        );
        if (seleccion >= 0 && seleccion < opciones.length) {
            salida = (String) opciones[seleccion];
        }
        return salida;
    }

    public static boolean preguntarSioNo(String pregunta, String titulo) {
        boolean salida = false;
        // 1. Define las etiquetas de los botones en espa�ol
        Object[] opcionesPersonalizadas = {"S�", "No"};

        // Puedes usar null si no quieres un icono o una de las constantes de JOptionPane
        Icon icono = null;

        // 2. Llama a showOptionDialog para usar las etiquetas
        int respuesta = JOptionPane.showOptionDialog(
                null, // Componente padre (null para centrar)
                pregunta, // Mensaje
                titulo, // T�tulo de la ventana
                JOptionPane.YES_NO_OPTION, // Tipo de botones (define el comportamiento)
                JOptionPane.QUESTION_MESSAGE, // Tipo de mensaje/icono (Pregunta)
                icono, // Icono a mostrar
                opcionesPersonalizadas, // *** ARRAY DE ETIQUETAS PERSONALIZADAS ***
                opcionesPersonalizadas[0] // Opci�n por defecto (Aqu� es "S�")
        );

        // 3. Manejar el resultado
        // Aunque los textos son personalizados, el valor retornado sigue siendo un entero:
        // 0 -> Opci�n 1 ("S�")
        // 1 -> Opci�n 2 ("No")
        // -1 -> Cerrar Ventana (X)
        salida = respuesta == 0;
        return salida;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        boolean resultadoBooleano = false;
        String resultadoString = null;

        resultadoBooleano = preguntarSioNo("�Hace calor?", "�C�mo va el clima?");
        if (resultadoBooleano) {
            System.out.println("Si, hace calor");
        } else {
            System.out.println("No, hace fr�o");
        }

        resultadoString = preguntarPorOpciones(new Object[]{"Rojo", "Azul", "Blanco"}, "�Cu�l es tu color preferido?", "Color preferido");
        if (resultadoString != null) {
            System.out.println("Color: " + resultadoString);
        } else {
            System.out.println("No hay color seleccionado");
        }

    }

}
