/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplos;

/**
 *
 * @author mauri
 */
public class Main {

    public static void llenarMatriz(int[][] matriz) {
        int contador = 0;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = contador++;
            }
        }
    }

    public static void imprimir(int[][] matriz) {
        String x = null;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                x = String.format("[%2d][%2d](%2d)", i, j, matriz[i][j]);
                System.out.print(x);
            }
            System.out.println("");
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] matrizEnterosSimetrica = new int[3][2];
        int[][] matrizEnterosAsimetrica = new int[4][];
        matrizEnterosAsimetrica[0] = new int[3];
        matrizEnterosAsimetrica[1] = new int[5];
        matrizEnterosAsimetrica[2] = new int[2];
        matrizEnterosAsimetrica[3] = new int[6];

        System.out.println("Largo pricipal " + matrizEnterosSimetrica.length);
        System.out.println("Largo secundario " + matrizEnterosSimetrica[0].length);
        llenarMatriz(matrizEnterosSimetrica);
        imprimir(matrizEnterosSimetrica);
        System.out.println("---");
        matrizEnterosSimetrica[2][0] = 77;
        imprimir(matrizEnterosSimetrica);
        
        System.out.println("---");
        llenarMatriz(matrizEnterosAsimetrica);
        imprimir(matrizEnterosAsimetrica);
        System.out.println("---");
        matrizEnterosAsimetrica[3][0] = 99;
        imprimir(matrizEnterosAsimetrica);        

    }

}
