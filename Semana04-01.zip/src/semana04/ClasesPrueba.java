/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package semana04;

/**
 *
 * @author mauri
 */
public class ClasesPrueba {
    
    public void ejemploFor3() {
        int x = 0;
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                x = i*100+j*10;
                System.out.printf("%3d ",x);
            }
            System.out.println("");
        }
    }
    
    public void ejemploFor2() {
        for (int i = 0; i < 11; i++) {
            System.out.printf("%2d - %6d\n",i, i*1000);
        }
    }
    
    public void ejemploFor1() {
        int factorial = 1,n=6;
        // n!  3!
        //3! = 3 * 2!
        //2! = 2 * 1!
        //1! = 1
        // 3! = 1 * 2 * 3
        
        System.out.println("--FOR--");
        for (int i = 1; i <= n; i++) {
            factorial = factorial * i;
        }
        System.out.printf("Factorial de n! (%6d!) es %6d\n", n, factorial);
                
        
        System.out.println("**FOR**");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ClasesPrueba m = new ClasesPrueba();
        m.ejemploFor1();
        m.ejemploFor2();
        m.ejemploFor3();
    }
    
}
