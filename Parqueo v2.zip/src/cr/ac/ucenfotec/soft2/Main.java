/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cr.ac.ucenfotec.soft2;

/**
 *
 * @author Mauricio Andr�s Zamora Hern�ndez
 */
public class Main {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Reloj casio = new Reloj();
//        System.out.println(casio.imprimirHora());
//        System.out.println(casio.darHora());
//        casio.setHora(20);
//        casio.setMinutos(45);
//        System.out.println(casio.imprimirHora());
//        System.out.println(casio.darHora());
//        casio.establecerHora(9, 15);
//        System.out.println(casio.imprimirHora());
//        System.out.println(casio.darHora());
//        casio.establecerHora(0, 0);
//        System.out.println(casio.imprimirHora());
//        casio.incrementarMinutos(1000);
//        System.out.println(casio.imprimirHora());
//        casio.incrementarMinutos(1000);
//        System.out.println(casio.imprimirHora());   
//        for (int i = 0; i < 100; i++) {
//            casio.incrementarMinutos();
//            System.out.println(casio.imprimirHora());   
//        }

        Camion c = new Camion();
        c.setPlaca("CMN123");
        Carro cc = new Carro();
        cc.setPlaca("BMW999");
        Vehiculo v = null;
        
        v = c;
        System.out.println(v.obtenerTarifa());
        System.out.println(v.devolverInformacion());
        v = cc;
        System.out.println(v.obtenerTarifa());
        System.out.println(v.devolverInformacion());
        
        Espacio e1 = new Espacio();
        System.out.println(e1.estaDisponible());
        e1.parquear(c, 12);
        System.out.println(e1.estaDisponible());
    }
    
}
