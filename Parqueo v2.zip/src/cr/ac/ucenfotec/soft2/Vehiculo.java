/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucenfotec.soft2;

/**
 *
 * @author Mauricio Zamora Hern�ndez
 */
public abstract class Vehiculo {
    private String placa;

    
    public String devolverInformacion() {
        String p = null;
        if (getPlaca() == null) {
            p = "N/D";
        } else {
            p = getPlaca();
        }
        String data = String.format("Placa: %6s pagando %7.2f colones / hora", p, obtenerTarifa());
        return data;
    }
    
    public abstract double obtenerTarifa();
    
    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }
}
