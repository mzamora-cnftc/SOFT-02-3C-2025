/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucenfotec.soft2;

/**
 *
 * @author Mauricio Andr�s Zamora Hern�ndez
 */
public class Espacio {
    private double horaIngreso;
    private int cantidadVehiculo;
    private double totalRecolectado;
    private Vehiculo vehiculo = null;
    
    public boolean parquear(Vehiculo v, double hora) {
        boolean respuesta = false;
        
        if (estaDisponible()) {
            respuesta = true;
            setHoraIngreso(hora);
            setVehiculo(v);
        }
        
        return respuesta;
    }
    
    public boolean estaDisponible() {
        return getVehiculo() == null;
    }
    
    
    /**
     * @return the horaIngreso
     */
    public double getHoraIngreso() {
        return horaIngreso;
    }

    /**
     * @param horaIngreso the horaIngreso to set
     */
    public void setHoraIngreso(double horaIngreso) {
        this.horaIngreso = horaIngreso;
    }

    /**
     * @return the cantidadVehiculo
     */
    public int getCantidadVehiculo() {
        return cantidadVehiculo;
    }

    /**
     * @param cantidadVehiculo the cantidadVehiculo to set
     */
    public void setCantidadVehiculo(int cantidadVehiculo) {
        this.cantidadVehiculo = cantidadVehiculo;
    }

    /**
     * @return the totalRecolectado
     */
    public double getTotalRecolectado() {
        return totalRecolectado;
    }

    /**
     * @param totalRecolectado the totalRecolectado to set
     */
    public void setTotalRecolectado(double totalRecolectado) {
        this.totalRecolectado = totalRecolectado;
    }

    /**
     * @return the vehiculo
     */
    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    /**
     * @param vehiculo the vehiculo to set
     */
    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }
    
    
    
    
}
