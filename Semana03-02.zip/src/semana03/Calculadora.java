/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package semana03;

/**
 *
 * @author mauri
 */
public class Calculadora {
    public static double PORCENTAJE_DESCUENTO = 0.35;
    
    public double calcularPrecioCono(boolean esAzucarado, int bolaReg, int bolaPrem){
        double monto = bolaReg * 500 + bolaPrem * 750 + 500;
        
        if (esAzucarado) {
            monto += 500;
            //monto = monto + 500;
        }
        
        return monto;
    }
    
    public double calcularPrecioBanana(boolean sabor1, boolean sabor2, 
            boolean sabor3, boolean sabor4, boolean sabor5, boolean sabor6, 
            String topping) {
    double monto = 0;
        int s1, s2, s3, s4, s5,s6;
        int cantidadOpciones;
        if (sabor1) {
            s1 = 1;
        } else {
            s1 = 0;
        }
        // if ternario
        s2 = sabor2?1:0;
        s3 = sabor3?1:0;
        s4 = sabor4?1:0;
        s5 = sabor5?1:0;
        s6 = sabor6?1:0;
        
        cantidadOpciones = s1 + s2 + s3 + s4 +s5 +s6;
        
        if (cantidadOpciones == 3)  {
            monto = 500 * 3;
            if ("Fresa".equalsIgnoreCase(topping)) {
                monto += 500;
            }else if ("Frutas".equalsIgnoreCase(topping)) {
                monto += 750;
            }else if ("Caramelo".equalsIgnoreCase(topping)) {
                monto += 1000;
            }else if ("Chocolate".equalsIgnoreCase(topping)) {
                monto += 900;
            }
        
        } else {
            monto = -1;
        }
    
    return monto;
    }
    
    
    public double calcularMontoConDescuento(int cantidadCompras, double montoCompra) {
     double montoDescuento;
        if (cantidadCompras >= 6 && montoCompra >= 10000) {
            montoDescuento = montoCompra * PORCENTAJE_DESCUENTO;
        } else {
            montoDescuento = 0;
        }
        
        return montoCompra - montoDescuento;
    }
    
}
