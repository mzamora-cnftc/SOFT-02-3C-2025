/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucenfotec.soft2.logic;

/**
 *
 * @author mauri
 */
public class Carro extends Vehiculo {

    @Override
    public double obtenerTarifa() {
        return 1000;
    }
    
}
