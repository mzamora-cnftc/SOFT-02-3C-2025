/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucenfotec.soft2.logic;

/**
 *
 * @author Mauricio Andr�s Zamora Hern�ndez
 */
public class Espacio {

    private double horaIngreso;
    private int cantidadVehiculo;
    private double totalRecolectado;
    private Vehiculo vehiculo = null;
    
    
    public Vehiculo retirarVehiculo(double hora) {
        double monto = calcularMonto(hora);
        setTotalRecolectado(getTotalRecolectado()+monto);
        Vehiculo temporal = getVehiculo();
        setVehiculo(null);
        return temporal;
    }
    
    public double calcularMonto(double hora) {
        double monto = 0;
        if(hayUnVehiculo()) {
            monto = calcularDuracion(hora) * getVehiculo().obtenerTarifa();
        }
        
        return monto;
    }

    public double calcularDuracion(double hora) {
        double total = 0;
        double duracion, fraccion;
        int horasEstuvo = 0;
        duracion = hora - getHoraIngreso();

        if (duracion <= 1) {
            total = 1;
        } else {
            horasEstuvo = (int) duracion;
            fraccion = duracion - horasEstuvo;
            if (fraccion == 0) {
                total = horasEstuvo;
            } else if (fraccion > 0.5) {
                total = horasEstuvo + 1;
            } else {
                total = horasEstuvo + 0.5;
            }
        }

        return total;
    }

    public boolean tieneEstaPlaca(String placa) {
        boolean respuesta = false;
        String placaDelVehiculo;
        if (hayUnVehiculo()) {
            //respuesta = getVehiculo().getPlaca().equalsIgnoreCase(placa);
            placaDelVehiculo = getVehiculo().getPlaca();
            respuesta = placaDelVehiculo.equalsIgnoreCase(placa);
        }

        return respuesta;
    }

    public int contarVehiculoDiarios() {
        return getCantidadVehiculo();
    }

    public boolean parquear(Vehiculo v, double hora) {
        boolean respuesta = false;

        if (estaDisponible()) {
            respuesta = true;
            setHoraIngreso(hora);
            setVehiculo(v);

            setCantidadVehiculo(getCantidadVehiculo() + 1);
        }

        return respuesta;
    }

    public boolean hayUnVehiculo() {
        return !estaDisponible();
    }

    public boolean estaDisponible() {
        return getVehiculo() == null;
    }

    /**
     * @return the horaIngreso
     */
    public double getHoraIngreso() {
        return horaIngreso;
    }

    /**
     * @param horaIngreso the horaIngreso to set
     */
    public void setHoraIngreso(double horaIngreso) {
        this.horaIngreso = horaIngreso;
    }

    /**
     * @return the cantidadVehiculo
     */
    public int getCantidadVehiculo() {
        return cantidadVehiculo;
    }

    /**
     * @param cantidadVehiculo the cantidadVehiculo to set
     */
    public void setCantidadVehiculo(int cantidadVehiculo) {
        this.cantidadVehiculo = cantidadVehiculo;
    }

    /**
     * @return the totalRecolectado
     */
    public double getTotalRecolectado() {
        return totalRecolectado;
    }

    /**
     * @param totalRecolectado the totalRecolectado to set
     */
    public void setTotalRecolectado(double totalRecolectado) {
        this.totalRecolectado = totalRecolectado;
    }

    /**
     * @return the vehiculo
     */
    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    /**
     * @param vehiculo the vehiculo to set
     */
    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

}
