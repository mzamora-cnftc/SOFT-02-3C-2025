/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucenfotec.soft2.logic;

/**
 *
 * @author Mauricio Zamora Hern�ndez
 */
public class Parqueo {
    private Espacio[] espacios;
    private double totalRecolectado;
    private Reloj reloj;

    public Parqueo() {
        reloj = new Reloj();
        reloj.establecerHora(8, 30);
        this.espacios = new Espacio[15];
        for (int i = 0; i < getEspacios().length; i++) {
            espacios[i] = new Espacio();
        }
    }
    
    public boolean estaDisponible() {
        boolean disponibilidad = false;
        
        for (Espacio espacio : getEspacios()) {
            if(espacio.estaDisponible()) {
                disponibilidad = true;
                break;
            }
        }
        
        return disponibilidad;
    }
    
    public Vehiculo retirarVehiculoPorPlaca(String numeroPlaca, double hora) {
        Vehiculo temporal = null;
        Espacio espacioActual;
        String placa;
        for(int i = 0; i < getEspacios().length; i++) {
            espacioActual = getEspacios()[i];
            if(espacioActual.hayUnVehiculo()) {
                placa = espacioActual.getVehiculo().getPlaca();
                if(placa.equalsIgnoreCase(numeroPlaca)) {
                    temporal = espacioActual.retirarVehiculo(hora);
                }
            }
        }
        
        return temporal;
    }
    
    public String mostrarInfo() {
        Espacio espacioActual;
        int hora, minutos;
        String placa;
        String reporte = String.format("%2s %5s %10s\n", "ID","HORA","PLACA");
        for (int i = 0; i < getEspacios().length; i++) {
            espacioActual = getEspacios()[i];
            if (espacioActual.hayUnVehiculo()) {
                hora = (int) espacioActual.getHoraIngreso();
                minutos = (int) ((espacioActual.getHoraIngreso() - hora) * 60);
                placa = espacioActual.getVehiculo().getPlaca();
                reporte = reporte + String.format("%02d %2d:%02d %10s\n", i+1,hora,minutos, placa);
            } else {
                reporte = reporte + String.format("%02d %5s %10s\n", i+1,"-","-");
            }
        }
        return reporte;
    }
    
    public int contarVehiculosDelDia() {
        int contador = 0;
        for (Espacio espacio : getEspacios()) {
            contador = contador + espacio.contarVehiculoDiarios();
        }
        return contador;
    }
    
    public boolean parquear(Vehiculo v) {
        boolean exito = false;
        Espacio espacioActual;
        for (int i = 0; i < getEspacios().length; i++) {
            espacioActual = getEspacios()[i];
            getReloj().incrementarMinutos(i*7);
            if (espacioActual.estaDisponible()){
                exito = true;
                espacioActual.parquear(v, getReloj().darHora());
                break;
            }
        }
        
        return exito;
    }
    
    public int contarEspaciosDisponibles() {
        int contador = 0;
        
        for(Espacio e : getEspacios()) {
            contador = contador + (int) (e.estaDisponible()?1:0);
        }
        
        return contador;
    }

    /**
     * @return the espacios
     */
    public Espacio[] getEspacios() {
        return espacios;
    }

    /**
     * @param espacios the espacios to set
     */
    public void setEspacios(Espacio[] espacios) {
        this.espacios = espacios;
    }

    /**
     * @return the totalRecolectado
     */
    public double getTotalRecolectado() {
        return totalRecolectado;
    }

    /**
     * @param totalRecolectado the totalRecolectado to set
     */
    public void setTotalRecolectado(double totalRecolectado) {
        this.totalRecolectado = totalRecolectado;
    }

    /**
     * @return the reloj
     */
    public Reloj getReloj() {
        return reloj;
    }

    /**
     * @param reloj the reloj to set
     */
    public void setReloj(Reloj reloj) {
        this.reloj = reloj;
    }
}
