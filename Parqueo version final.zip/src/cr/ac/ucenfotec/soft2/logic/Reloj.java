/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucenfotec.soft2.logic;

/**
 * Esta clase contiene la definici�n de un reloj de 24 horas, que me va ayudar a
 * establecer la hora simulada del ejercicio.
 *
 * @author Mauricio Andr�s Zamora Hern�ndez
 */
public class Reloj {

    private int hora;
    private int minutos;

    public Reloj() {
        setHora(12);
        setMinutos(0);
    }

    public double darHora() {
        return getHora() + getMinutos() / 60d;
    }

    public void establecerHora(int hora, int minutos) {
        setHora(hora);
        setMinutos(minutos);
    }
    
    /**
     * Este m�todo incrementa en un minuto al valor reloj
     */
    public void incrementarMinutos() {
        incrementarMinutos(1);
    }

    public void incrementarMinutos(int minutos) {
        int minutosActuales = getMinutos();
        int minutosNuevos;
        int horasActuales = getHora();
        int horaNueva;
        minutosActuales += minutos;
        minutosNuevos = minutosActuales % 60;
        setMinutos(minutosNuevos);
        horaNueva = minutosActuales / 60;
        horaNueva = (horaNueva + horasActuales) % 24;
        setHora(horaNueva);
    }

    /**
     * @return the hora
     */
    public int getHora() {
        return hora;
    }

    /**
     * @param hora the hora to set
     */
    public void setHora(int hora) {
        if (hora >= 0 && hora < 24) {
            this.hora = hora;
        }
    }

    /**
     * @return the minutos
     */
    public int getMinutos() {
        return minutos;
    }

    /**
     * @param minutos the minutos to set
     */
    public void setMinutos(int minutos) {
        if (minutos >= 0 && minutos < 60) {
            this.minutos = minutos;
        }
    }

    public String imprimirHora() {
        return String.format("%02d:%02d", getHora(), getMinutos());
    }

}
