/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cr.ac.ucenfotec.soft2;

import cr.ac.ucenfotec.soft2.logic.Carro;
import cr.ac.ucenfotec.soft2.logic.Parqueo;
import cr.ac.ucenfotec.soft2.logic.Camion;

/**
 *
 * @author Mauricio Andr�s Zamora Hern�ndez
 */
public class Main {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Reloj casio = new Reloj();
//        System.out.println(casio.imprimirHora());
//        System.out.println(casio.darHora());
//        casio.setHora(20);
//        casio.setMinutos(45);
//        System.out.println(casio.imprimirHora());
//        System.out.println(casio.darHora());
//        casio.establecerHora(9, 15);
//        System.out.println(casio.imprimirHora());
//        System.out.println(casio.darHora());
//        casio.establecerHora(0, 0);
//        System.out.println(casio.imprimirHora());
//        casio.incrementarMinutos(1000);
//        System.out.println(casio.imprimirHora());
//        casio.incrementarMinutos(1000);
//        System.out.println(casio.imprimirHora());   
//        for (int i = 0; i < 100; i++) {
//            casio.incrementarMinutos();
//            System.out.println(casio.imprimirHora());   
//        }

        Camion truck = new Camion();
        truck.setPlaca("CMN123");
        Carro car = new Carro();
        car.setPlaca("BMW999");
        Carro car2 = new Carro();
        car2.setPlaca("ADI123");
        Carro car3 = new Carro();
        car3.setPlaca("TYT676");        
        
        
        Parqueo miEmprendiento = new Parqueo();
        System.out.println(miEmprendiento.contarEspaciosDisponibles());
        System.out.println(miEmprendiento.mostrarInfo());
        miEmprendiento.parquear(car);
        System.out.println(miEmprendiento.contarEspaciosDisponibles());
        System.out.println(miEmprendiento.mostrarInfo());
        miEmprendiento.parquear(truck);
        System.out.println(miEmprendiento.contarEspaciosDisponibles());
        System.out.println(miEmprendiento.mostrarInfo());
        miEmprendiento.parquear(car2);
        System.out.println(miEmprendiento.contarEspaciosDisponibles());
        System.out.println(miEmprendiento.mostrarInfo());        
        miEmprendiento.parquear(car3);
        System.out.println(miEmprendiento.contarEspaciosDisponibles());
        System.out.println(miEmprendiento.mostrarInfo());
        System.out.println("Retiro vehiculo con placa CMN123");
        //miEmprendiento.retirarVehiculoPorPlaca("CMN123");
        System.out.println(miEmprendiento.mostrarInfo());
        
        System.out.println("Retiro vehiculo con placa TYT676");
        //miEmprendiento.retirarVehiculoPorPlaca("TYT676");
        System.out.println(miEmprendiento.mostrarInfo());        
    }
    
}
